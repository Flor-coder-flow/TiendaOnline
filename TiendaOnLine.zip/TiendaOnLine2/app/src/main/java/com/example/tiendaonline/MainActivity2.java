package com.example.tiendaonline;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;


public class MainActivity2 extends AppCompatActivity {

    private List<Productos> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lista = new ArrayList<Productos>();
        lista.add(new Productos("1","SmartWatch","smartwatch","LG 2024","100 usd"));
        lista.add(new Productos("2","PC","pc","Samsung","300 usd"));
        lista.add(new Productos("3","Dron","dron","Lenovo","1500 usd"));

        AdaptadorProductos adaptador = new AdaptadorProductos(this);
        ListView lv1 = (ListView) findViewById(R.id.productosList);
        lv1.setAdapter(adaptador);
    }

    class AdaptadorProductos extends ArrayAdapter<Productos> {
        AppCompatActivity appCompatActivity;

        AdaptadorProductos(AppCompatActivity context) {
            super(context, R.layout.producto, lista);
            appCompatActivity = context;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = appCompatActivity.getLayoutInflater();
            View item = inflater.inflate(R.layout.producto, null);

            TextView titulo = (TextView) item.findViewById(R.id.tituloTxt);
            titulo.setText(lista.get(position).getProducto());
            TextView detalle = (TextView) item.findViewById(R.id.detalleTxt);
            detalle.setText(lista.get(position).getDetalle());
            TextView precio = (TextView) item.findViewById(R.id.precioTxt);
            precio.setText(lista.get(position).getPrecio());

            ImageView imageView = (ImageView) item.findViewById(R.id.productoImg);
            int id = getResources().getIdentifier(lista.get(position).getImagenPath(), "drawable", getPackageName());
            imageView1.setImageResource(id);
            return (item);
        }
    }

}